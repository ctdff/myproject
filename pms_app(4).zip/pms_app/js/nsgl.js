define(["jquery","cache","common","mui","picker"],function($,Cache,common,mui,picker){
	var nsgl = {
		bindClick:function(){
			//农事操作列表
			$(".oprate img").click(function(){
				var type = $(".mui-control-item.mui-active").attr("id");
				var radioName= type+"_radio";
				//必须先选中档案再进行操作
				var checkId=$("input[name="+radioName+"]:checked").val();
				console.log(radioName,checkId)
				if(checkId==undefined||checkId==null){
					mui.toast("请选择对应的档案进行操作!");
					return false;
				}
				var text = this.name;
				$("#czTitle").html(text);
				//窗出框
				mui('#czPopover').popover('toggle');//show hide toggle
				mui(".mui-numbox").numbox();
				
			});
			$("footer ul li").unbind("click");
			$("footer ul li").click(function(){
				var url = $(this).data("u");
				$(this).addClass("active").siblings().removeClass("active");
				router.go(url);
			})
			nsgl.bindPopoverEvent();
		},
		//绑定弹出框事件
		bindPopoverEvent:function(){
			$("#cancel").click(function(){
				console.log("取消");
				mui('#czPopover').popover('hide');//show hide toggle
			})
			$("#save").click(function(){
				console.log("保存");
			});
			/*var dtPicker = new mui.DtPicker(); //初始化一次
			$("#time").click(function(){
				//$("#czPopover").css("z-index","10");
			     dtPicker.show(function (rs) { 
			     	$("#time").val(rs.text) 
			    })
			});*/
		},
		getRadioRes:function(className){
			var rdsObj = document.getElementsByClassName(className);
			var checkVal = null;
			for(i = 0; i < rdsObj.length; i++){
				if(rdsObj[i].checked){
					checkVal = rdsObj[i].value;
				}
			}
			return checkVal;
		}
	};
	
	return {
		init:function(){
			console.log("初始化列表");
			mui('.mui-scroll-wrapper').scroll();//触发滚动 
			mui(".mui-slider").slider();//滑动效果
			nsgl.bindClick();
		}
	}
});