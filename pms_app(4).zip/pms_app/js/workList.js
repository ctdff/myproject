define(["jquery","cache","common","mui","pullToRefresh"],function($,Cache,common,mui,pullToRefresh){
	var workList = {
		bindClick:function(){
			
		},
		//根据类型获取操作列表
		getScrollDataByType:function(type){
			//种植：播种、施肥、施药、采收、检测；
			//畜牧：饲喂、治疗、免疫、消毒、出栏、转舍、损耗、补打；
			//渔业：投苗、投料、用药、捕捞、转池、损耗、检测
			var totals = {'zz':[{id:'zz_all',name:'全部'},{id:'zz_bozhong',name:'播种'},
			{id:'zz_shifei',name:'施肥'},{id:'zz_shiyao',name:'施药'},
			{id:'zz_caishou',name:'采收'},{id:'zz_jiance',name:'检测'}],
			'xm':[{id:'xm_all',name:'全部'},{id:'xm_siwei',name:'饲喂'},{id:'xm_zhiliao',name:'治疗'},{id:'xm_mianyi',name:'免疫'},{id:'xm_xiaodu',name:'消毒'},{id:'xm_chulan',name:'出栏'},{id:'xm_zhuanshe',name:'转舍'},{id:'xm_sunhao',name:'损耗'},{id:'xm_buda',name:'补打'}],
			'yy':[{id:'yy_all',name:'全部'},{id:'yy_toumiao',name:'投苗'},
			{id:'yy_touliao',name:'投料'},{id:'yy_yongyao',name:'用药'},
			{id:'yy_bulao',name:'捕捞'},{id:'yy_zhuanchi',name:'转池'},{id:'yy_sunhao',name:'损耗'},{id:'yy_jiance',name:'检测'}]}
			
			var data = totals[type];
			console.log(data);
			return data;
		},
		//初始化操作列表
		initscrollTab:function(array){
			var tabHtml=``;
			var groupHtml=``;
			$.each(array, function(index,item) {
				var active = index==0?"mui-active":"";
				tabHtml+=`<a class="mui-control-item `+active+`" href="#item_`+item.id+`">
						`+item.name+`
					</a>`;
				groupHtml+=`<div id="item_`+item.id+`" class="mui-slider-item mui-control-content">
					<div class="mui-scroll-wrapper">
						<div class="mui-scroll">
							<ul>
								<li class="item">
										<div class="row">
											<span class="type">`+item.name+`</span>
											/111
											<span class="area">2019-10-10 09:09</span>
										</div>
										
										<div class="infos">操作人：
											<span class="rit">种植合作社</span>     
										</div>
										<div class="infos">某某肥料：
											<span class="rit">20KG</span>
										</div>
									</li>
							</ul>
						</div>
					</div>
				</div>`;
			});
			$("#scrollTab").html(tabHtml);
			$("#sliderGroup").html(groupHtml);
			mui('.mui-scroll-wrapper').scroll();//触发滚动
			mui(".mui-slider").slider();//这句话必要
			workList.initPage();
		},
		initPage:function(){
			$.each(document.querySelectorAll('.mui-slider-group .mui-scroll'), function (index, pullRefreshEl) {
	            mui(pullRefreshEl).pullToRefresh({
	            	down: {
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							setTimeout(function() {
								console.log("刷新");
								$(ul).attr("curpage",1);
								self.refresh(true);
								self.endPullDownToRefresh();
								//home.createFragment(ul,index,self,1,true);        
							}, 1000);
						}
					},
					up: {
						auto:index==0?true:false, //自动执行一次上拉加载，可选；
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							var pageNum = Number($(ul).attr("curpage"));
							setTimeout(function() {
								console.log("加载");
								self.endPullUpToRefresh(false);
								//home.createFragment(ul,index,self,pageNum);        
							}, 1000);
						}
					}
	            });
	        });
		},
		appendContent:function(type){
			//scrollTab
			var html=`<a class="mui-control-item" href="#item_siwei">
						饲喂
					</a>`;
			$("#scrollTab").append(html);
			var group=`<div id="item_siwei" class="mui-slider-item mui-control-content">
					<div class="mui-scroll-wrapper">
						<div class="mui-scroll">
							<ul>
								<li class="item">
									<div class="row">
										<span class="type">播种</span>
										/111
										<span class="area">2019-10-10 09:09</span>
									</div>
									
									<div class="infos">操作人：
										<span class="rit">种植合作社</span>     
									</div>
									<div class="infos">某某肥料：
										<span class="rit">20KG</span>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>`
			$("#sliderGroup").append(group);
			mui('.mui-scroll-wrapper').scroll();//触发滚动
			mui(".mui-slider").slider();//这句话必要
		}
	};
	
	return {
		init:function(){
			console.log("初始化列表");
			
			$("footer").hide();
			var offsetHeight= document.body.offsetHeight;
			var height=offsetHeight-52;
			$("#content").height(height);
			$("#slider").css("bottom","0");
			//初始化分页
			//workList.appendContent("siwei");
			var typeCode = Cache.get("typeCode",typeCode);
			var array = workList.getScrollDataByType(typeCode);
			//var array1 = [{id:'all',name:'全部'},{id:'siwei',name:'饲喂'},{id:'zhiliao',name:'治疗'},{id:'mianyi',name:'免疫'},{id:'xiaodu',name:'消毒'},{id:'chulan',name:'出栏'}];
			workList.initscrollTab(array);
		}
	}
});