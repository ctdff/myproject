define(["jquery","cache","mui","common"],function($,Cache,mui,common){
	//初始化验证码
	var timeId = "";
	var loginUrl="http://guangzhou.project.agrisaas.com.cn/ppf";
	var loginIn = {
		initInfo:function(){
			timeId=new Date().getTime();
			var validateCodeSrc = loginUrl+"/validateCode?codeId="+timeId;
			console.log(timeId);
			$("#showValidateCode").attr("src",validateCodeSrc);
			$("#showValidateCode").on("click",function(){
				timeId = new Date().getTime();
				console.log(timeId);
				$("#showValidateCode").attr("src",validateCodeSrc+"&d="+timeId);
			});
   
   
			var userInfo = Cache.getJSON("pms-app-user");
			console.log("初始化",userInfo);
			if(userInfo !== null){
				$("#userName").val(userInfo.username);
				$("#password").val(userInfo.password);
			}
			$("footer").hide();
		},
		bindClick:function(){
			$("#loginBtn").click(function(){
				var enabledClick = true;
				var username=$("#userName").val();
				var password = $("#password").val();
				var validateCode = $("#validateCode").val();
				var remember =false;
				if(username==""){
					mui.toast("请输入用户名");
					return;
				}
				if(password==""){
					mui.toast("请输入密码");
					return;
				}
				if(validateCode==""){
					mui.toast("请输入验证码");
					return;
				}
				mui('.mui-btn').button('loading');
				if(enabledClick){
					enabledClick = false;
					//http://guangzhou.project.agrisaas.com.cn/ppf/login?codeId=1568879028433
					$.ajax({
						type:"post",
						url:loginUrl+"/login",
						data:"loginName="+username+"&password="+password+"&validateCode="+validateCode+"&codeId="+timeId,
						dataType:"json",
						success:function(res){
							console.log(res);
							if(res.status == 200){
								
								
								Cache.set("pms-app-user", {"loginName":username,"loginUserId":res.data.id,"token":res.data.jwt.replace(/\+/g,"%2B"), "isLogin":1});
								mui.toast("登录成功")
								setTimeout(function(){
									//window.location.hash = "#/home";
									router.go("#/home")
								},500);
							}else{
								mui.toast((res.msg?res.msg:"")+"登录失败.");
								mui('.mui-btn').button('reset');
							}
						},
						error:function(){
							mui.toast((res.msg?res.msg:"")+"登录失败.");
							mui('.mui-btn').button('reset');
						}
					});
					
				}
				
			})
			
		}
	};
	
	return {
		init:function(){
			console.log("login js");
			loginIn.initInfo();
			loginIn.bindClick();
		}
	}
});

		
	
