define(["jquery","cache","common","mui","pullToRefresh","template"],function($,Cache,common,mui,pullToRefresh,template){
	var userInfo ;
	var home = {
		getScrollData:function(){
	        $.ajax({
	        	type:"get",
	        	url:"/select/industry_categories",
	        	data:{cId:'1,2'},
	        	success:function(res){
	        		console.log(res);
	        		home.initscrollTab(res.data);
	        	}
	        });
		},
		//初始行业类型
		initscrollTab:function(array){
			var tabHtml=``;
			var groupHtml=``;
			$.each(array, function(index,item) {
				var active = index==0?"mui-active":"";
				tabHtml+=`<a class="mui-control-item `+active+`" href="#item_`+item.id+`">
						`+item.cName+`
					</a>`;
				groupHtml+=`<div id="item_`+item.id+`" class="mui-slider-item mui-control-content">
					<div class="mui-scroll-wrapper">
						<div class="mui-scroll">
							<ul id="ul_`+item.id+`">
								<li class="item">
										<div class="row">
											<span class="type">`+item.cName+`</span>
											/111
											<span class="area">2019-10-10 09:09</span>
										</div>
										
										<div class="infos">操作人：
											<span class="rit">种植合作社</span>     
										</div>
										<div class="infos">某某肥料：
											<span class="rit">20KG</span>
										</div>
									</li>
							</ul>
						</div>
					</div>
				</div>`;
			});
			$("#pro_type").html(tabHtml);
			$("#homeSlider").html(groupHtml);
			mui('.mui-scroll-wrapper').scroll();//触发滚动
			mui(".mui-slider").slider();//这句话必要
			//workList.initPage();
		},
		//获取种植档案数据
		getFarmingPlans:function(type){
			var param={cId:type,pageNumber:'1',pageSize:10,epId:'',
			farmingStatus:0,baseId:'1c62deb13fa743648df747c3666f4496'};
	        $.ajax({
	        	type:"get",
	        	url:"/farmingPlans",
	        	data:param,
	        	success:function(res){
	        		console.log(res);
	        		//home.initscrollTab(res.data);
	        	}
	        });
		},
		bindClick:function(){
			//点击事件
			mui('#homeSlider').on('tap', '.item', function() {
				var id = this.id;
				var typeCode =$("#pro_type").find(".mui-active").attr("id");
				console.log(id,typeCode);
				//保存 跳转 类型
				Cache.set("typeCode",typeCode);
				router.go("#/workList")
				//跳转到列表页面
			});
		},
		initPage:function(){
			$("footer ul li").unbind("click");
			$("footer ul li").click(function(){
				var url = $(this).data("u");
				$(this).addClass("active").siblings().removeClass("active");
				router.go(url);
			});
			//循环初始化所有下拉刷新，上拉加载。
	        $.each(document.querySelectorAll('.mui-slider-group .mui-scroll'), function (index, pullRefreshEl) {
	        	//console.log(pullRefreshEl);
	            mui(pullRefreshEl).pullToRefresh({
	            	down: {
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							setTimeout(function() {
								console.log("刷新");
								$(ul).attr("curpage",1);
								mui(pullRefreshEl).pullToRefresh().refresh(true);
								home.createFragment(ul,index,self,1,true);        
							}, 1000);
						}
					},
					up: {
						auto:index==0?true:false, //自动执行一次上拉加载，可选；
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							var pageNum = Number($(ul).attr("curpage"));
							setTimeout(function() {
								console.log("加载");
								home.createFragment(ul,index,self,pageNum);        
							}, 1000);
						}
					}
	            });
	        });
			
			
		},
		createFragment:function(ul,index,self,pageNum,reverse) {
	        var ajaxUrl=null;
	        //选择状态
	        if(index == 0){
	           ajaxUrl = 'aptmp-farmingtrace/rest/plantInfo/v1/search';
	        }else if(index == 1){
	            ajaxUrl ='aptmp-breedingtrace/rest/archiveInfo/v1/search';
	        }else if(index == 2){
	           ajaxUrl = 'aptmp-aquatictrace/rest/breedInfo/v1/search';  
	        }
	        var tempName = "template_"+index;
	        var postData = {tenantId:userInfo.tenantId,orgId:userInfo.orgId,
			P_pageNumber:pageNum,P_pagesize:1};
	       /* mui.post(common.requestUri+ajaxUrl,JSON.stringify(postData),function(res){
	        	console.log(res);
	        	if(res.status==200){
	        		var datas =res.result.data;
	        		if(datas.length == 0){
	                	$(ul).find('li').remove();
	                   self.endPullUpToRefresh(true);
	                }else{
	                	var html = template(tempName, {list:datas});
						if(reverse){
							$(ul).empty();
							self.endPullDownToRefresh();
						}
						$(ul).append(html);//对应的ul
						//总页数大于当前页面
						var hasNext = res.result.totalPages>res.result.pageNumber;
						if(hasNext){
							pageNum++;
							$(ul).attr("curpage",pageNum);
						}
	                	self.endPullUpToRefresh(!hasNext);
	                }
	        	}
	        });*/
	      
	        
	        
	        
		}
	};
	return {
		init:function(){
			console.log("初始化首页");
			userInfo = Cache.getJSON("pms-app-user"); 
			$('footer').show();
			mui(".mui-slider").slider();//滑动效果
			mui.ready(function() {
				home.getScrollData();
				//home.initPage();
				home.bindClick();
				home.getFarmingPlans(1);
			});
		   	itemShow=true;
			item2Show = false,item3Show = false;
			/*document.querySelector('.mui-slider').addEventListener('slide', 
			function(event) {
				var index =event.detail.slideNumber;
					var  pullRefreshEl = document.querySelectorAll('.mui-slider-group .mui-scroll')[index];
				//主动触发上拉加载
				if(index=== 0&&!itemShow){
			  		itemShow=true;
				}else if (index=== 1&&!item2Show) {
					mui(pullRefreshEl).pullToRefresh().pullDownLoading();
				    item2Show = true;//改变标志位，下次直接显示
				} else if (index === 2&&!item3Show) {
					mui(pullRefreshEl).pullToRefresh().pullDownLoading();
				    item3Show = true;
				}
			});*/
		}
	}
});