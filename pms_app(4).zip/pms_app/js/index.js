define(["jquery", "cache", "mui","router"], function($, Cache, mui,router) {
	if(window.location.hash == "") {
		return router.go("/login");
	}
});