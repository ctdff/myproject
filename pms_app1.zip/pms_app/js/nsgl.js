define(["jquery","cache","common","mui","picker","template"],function($,Cache,common,mui,picker,template){
	var nsgl = {
		getScrollData:function(){
		    $.ajax({
		    	type:"get",
		    	url:"/select/industry_categories",
		    	data:{cId:'1,2'},
		    	success:function(res){
		    		console.log(res);
		    		nsgl.initscrollTab(res.data);
		    	}
		    });
		},
		initscrollTab:function(array){
			var tabHtml=``;
			var groupHtml=``;
			$.each(array, function(index,item) {
				var active = index==0?"mui-active":"";
				tabHtml+=`<a id=`+item.id+` class="mui-control-item `+active+`" href="#item_`+item.id+`">
						`+item.cName+`
					</a>`;
				groupHtml+=`<div id="item_`+item.id+`" class="mui-slider-item mui-control-content">
					<div class="mui-scroll-wrapper nsczwrapper">
						<div class="mui-scroll">
							<ul id="ul_`+item.id+`">
							</ul>
						</div>
					</div>
					<div class="oprate" id="oprate_`+item.id+`">
					</div>
				</div>`;
			});
			$("#pro_type").html(tabHtml);
			$("#groupSlider").html(groupHtml);
			mui('.mui-scroll-wrapper').scroll();//触发滚动
			mui(".mui-slider").slider();//这句话必要
			nsgl.initPage();
		},
		initPage:function(){
			$("footer ul li").unbind("click");
			$("footer ul li").click(function(){
				var url = $(this).data("u");
				$(this).addClass("active").siblings().removeClass("active");
				router.go(url);
			});
			//循环初始化所有下拉刷新，上拉加载。
		    $.each(document.querySelectorAll('.mui-slider-group .mui-scroll'), function (index, pullRefreshEl) {
		    	//console.log(pullRefreshEl);
		        mui(pullRefreshEl).pullToRefresh({
		        	down: {
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							setTimeout(function() {
								console.log("刷新");
								$(ul).attr("curpage",1);
								nsgl.createFragment(ul,index,self,1,true);        
							}, 1000);
						}
					},
					up: {
						auto:index==0?true:false, //自动执行一次上拉加载，可选；
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							var pageNum = Number($(ul).attr("curpage"));
							setTimeout(function() {
								console.log("加载");
								nsgl.createFragment(ul,index,self,pageNum);        
							}, 1000);
						}
					}
		        });
		    });
			
			
		},
		createFragment:function(ul,index,self,pageNum,reverse) {
		    var ajaxUrl=null;
		    var type = ul.id.split("_")[1];//行业类型
		    nsgl.getOprageData(type);
			var baseId = Cache.getJSON("pms-userInfo").id;//1c62deb13fa743648df747c3666f4496
			var param={cId:type,pageNumber:pageNum,pageSize:10,epId:'',
			farmingStatus:0,baseId:baseId};
		    $.ajax({
		    	type:"get",
		    	url:"/farmingPlans",
		    	data:param,
		    	success:function(res){
		    		console.log(res);
		    		if(res.status==200){
		        		var datas =res.data;
		        		if(datas.length == 0){
		                  $(ul).find('li').remove();
		                  self.endPullUpToRefresh(true);//一定要设置为true
		                }else{
		                	$.each(datas,function(index,item){
		                		var farmingPlanAreas = item.farmingPlanAreas;
		                		var totalArea=0;
								var areaIds=[];
		                		var areaNames=[];
		                		$.each(farmingPlanAreas,function(i,it){
									areaIds.push(it.areaId);
		                			areaNames.push(it.areaName);
		                			totalArea+=it.farmingArea;
		                		});
								item.areaIds=areaIds.join(",");//提交用
		                		item.areaNames=areaNames.join(",");
		                		item.totalArea=totalArea;
		                	});
		                	var html = template("template_nsgl", {list:datas});
							if(reverse){
								$(ul).empty();
								self.endPullDownToRefresh();
							}
							$(ul).append(html);//对应的ul
							//总页数大于当前页面
							var hasNext = res.totalPage>pageNum;
							if(hasNext){
								pageNum++;
								$(ul).attr("curpage",pageNum);
							}
		                	self.endPullUpToRefresh(!hasNext);
		                }
		        	}
		    	}
		    });
		},
		//获取操作列表
		getOprageData:function(cId){
			console.log(cId);
			$.ajax({
				type:"get",
				url:"/farming/work_types",
				data:{cId:cId},
				success:function(res){
					console.log(res);
					var html=``;
					$.each(res.data,function(index,item){
						
						html+=`<button   id="`+item.id+`" nztype=`+item.nzType+` type="button" 
						wCode=`+item.wCode+` formId="`+item.formId+`" isUsedNz=`+item.isUsedNz+` class="mui-btn mui-btn-primary">`+item.wName+`</button>`;
					});
					$("#oprate_"+cId).append(html);
					/* $("#"+item.id).click(function(){
						//根据操作id 获取操作表格
						//nsgl.getOprateFormData(this.id);
						nsgl.fillFormData(cId,this);
					}); */
					mui("#oprate_"+cId).on('tap', 'button', function() {
						$("#synzIdv").hide();
						nsgl.fillFormData(cId,this);
					});
					
				}
			});
		},
		fillFormData:function(cId,obj){
			var wtId = $(obj).attr("id");
			var text= $(obj).text();
			
			$("#czTitle").html(text);
			$("#czTitle").attr("wCode",$(obj).attr("wCode"));
			
			//付在form属性上
			$("#myform").attr("wtId",wtId);
			$("#myform").attr("formId",$(obj).attr("formId"));
			var radioName= "radio_"+cId;
			var checkId=$("input[name="+radioName+"]:checked").val();
			if(checkId==undefined||checkId==null){
				mui.toast("请选择对应的档案进行操作!");
				return false;
			}
			$.ajax({
				type:"get",
				url:"/work_form_items",
				data:{wtId:wtId},
				success:function(res){
					console.log(res.data);
					//填充弹出框模板
					//inputType 
					var html = template("createRowData", {list:res.data});
					var workFormItems = res.data;
					Cache.set("workFormItems",workFormItems);//读取缓存
					
					$("#myData").html(html);
					//var  inputsObj = $("#inputs");//投入品对象
					var isUsedNz = $(obj).attr("isUsedNz");//是否添加投入品
					if(isUsedNz==1){
						var  nztype = $(obj).attr("nztype");
						nsgl.getInputsStock(nztype);
					}
					var czrObj = $("#czr");//操作人对象
					if(czrObj.length>0){
						nsgl.getbaseStaffs();
					}
					//采收作物
					if($("#cszw").length>0){
						var cId =$("#pro_type").find(".mui-active").attr("id");
						var radioName= "radio_"+cId;
						var radioObj  = $("input[name="+radioName+"]:checked");
						var li = radioObj.parent().parent();
						var productId = li.attr("productId");
						//填充下拉框
						var proName =li.find("label")[0].childNodes[0].nodeValue.trim();
						var html=`<option id=`+productId+`>`+proName+`</option>`;
						$("#cszw").append(html);
					}
					//窗出框
					mui('#czPopover').popover('toggle');//show hide toggle
					
				}
			}); 
			
			
		},
		getInputsStock:function(inputProType){
			$("#synzIdv").show();
			//操作的nztype 
			var epId = Cache.getJSON("pms-app-user").loginUserId;
			var searchParams = {page:1,limit:10,epId:epId,inputProType:inputProType};
			$.ajax({
				type:"get",
				url:"/inputsStock",
				data:searchParams,
				success:function(res){
					console.log(res.data);
					//填充弹出框模板
					var html=``;
					$.each(res.data,function(index,item){
						html+=`<li class="mui-table-view-cell" id=`+item.id+` inputsId=`+item.inputsId+`
						productionDate=`+item.productionDate+` shelfLife=`+item.shelfLife+`>
								<span style="width: 60%;">`+item.inputProName+`(剩余`+item.stockQuantity+item.unit+`)</span>
								<div class="mui-numbox" data-numbox-min='0' >
								  <button class="mui-btn mui-numbox-btn-minus" type="button">-</button>
								  <input id="ipt_`+item.id+`" class="mui-numbox-input" type="number" value="1" />
								  <button class="mui-btn mui-numbox-btn-plus" type="button">+</button>
								</div>
							</li>`;
					})
					$("#synzIdv").find("ul").html(html);
					mui(".mui-numbox").numbox();
				}
			}); 



		},
		//获取操作人列表
		getbaseStaffs:function(){
			var epId = Cache.getJSON("pms-app-user").loginUserId;
			$.ajax({
				type:"get",
				url:"/base_staffs",
				data:{epId:epId},
				success:function(res){
					console.log(res.data);
					//填充弹出框模板
					var html=``;
					$.each(res.data,function(index,item){
						html+=`<option value=`+item.id+`>`+item.userName +`</option>`;
					})
					$("#czr").html(html);
				}
			}); 
			
		},
		getOprateFormData:function(wtId){
			
			
			
		},
		bindClick:function(){
			mui('.oprate').on('tap', 'button', function() {
				var type = $(".mui-control-item.mui-active").attr("id");
				var radioName= type+"_radio";
				//必须先选中档案再进行操作
				var checkId=$("input[name="+radioName+"]:checked").val();
				console.log(radioName,checkId)
				if(checkId==undefined||checkId==null){
					mui.toast("请选择对应的档案进行操作!");
					return false;
				}
				var text = this.name;
				$("#czTitle").html(text);
				//窗出框
				mui('#czPopover').popover('toggle');//show hide toggle
				mui(".mui-numbox").numbox();
			});
			//农事操作列表
			/* $(".oprate button").click(function(){
				var type = $(".mui-control-item.mui-active").attr("id");
				var radioName= type+"_radio";
				//必须先选中档案再进行操作
				var checkId=$("input[name="+radioName+"]:checked").val();
				console.log(radioName,checkId)
				if(checkId==undefined||checkId==null){
					mui.toast("请选择对应的档案进行操作!");
					return false;
				}
				var text = this.name;
				$("#czTitle").html(text);
				//窗出框
				mui('#czPopover').popover('toggle');//show hide toggle
				mui(".mui-numbox").numbox();
				
			}); */
			$("footer ul li").unbind("click");
			$("footer ul li").click(function(){
				var url = $(this).data("u");
				$(this).addClass("active").siblings().removeClass("active");
				router.go(url);
			})
			nsgl.bindPopoverEvent();
		},
		//绑定弹出框事件
		bindPopoverEvent:function(){
			$("#cancel").click(function(){
				console.log("取消");
				mui('#czPopover').popover('hide');//show hide toggle
			})
			$("#save").click(function(){
				console.log("保存");
				var  url="work_infos";
				var cId =$("#pro_type").find(".mui-active").attr("id");
				var baseNo = Cache.getJSON("pms-userInfo").baseNo;
				console.log(baseNo);
				var formData = $("#myform").serialize();
				var radioName= "radio_"+cId;
				
				var radioObj  = $("input[name="+radioName+"]:checked");
				var areaIds =$("input[name="+radioName+"]:checked").attr("areaIds");
				var wtCode=$("#czTitle").attr("wCode");
				var workTypeName= $("#czTitle").text();
				var wtId = $("#myform").attr("wtId");
				var formId = $("#myform").attr("formId");
				var farmer = $("#czr option:selected").text();//操作人
				var inputs=[];
				var inputsLis = $("#synzIdv li");
				$.each(inputsLis,function(index,item){
					var inputVal = $(item).find("input").val();
					if(inputVal!=0){
						console.log(inputVal);
						var obj = {id:$(item).attr("id"),
							inputsId:$(item).attr("inputsId"),
							productionDate:$(item).attr("productionDate"),
							shelfLife:$(item).attr("shelfLife"),
							stockQuantity:inputVal};
						inputs.push(obj);
					}
				});
				var li = radioObj.parent().parent();
				var planId = li.attr("id");
				var farmingArea = li.attr("farmingArea");
				console.log(planId,farmingArea);
				//bfb929d2bc034be48a714881faf356f7 这里有问题？？
				var planAreas=[{farmingArea:farmingArea,id:planId}];
				//postData 请求接口参数
				var workFormItems = Cache.getJSON("workFormItems");
				$.each(workFormItems,function(index,item){
					var fieldCode = item.fieldCode;
					console.log(fieldCode);
					console.log($("#"+fieldCode).length);
					if($("#"+fieldCode).length>0){
						item.filedValue=$("#"+fieldCode).val();
					}
				});
				var postData=
				{areaIds:areaIds,baseNo:baseNo,cId: cId,
				farmer: farmer,formId: formId,
				imagesArr:[],
				inputs:inputs,
				mId:'',
				planAreas:planAreas,
				workFormItems:workFormItems,
				workTypeName:workTypeName,
				wtCode:wtCode,
				wtId:wtId};
				console.log(postData);
				var d = JSON.stringify(postData);
				$.ajax({
					type:"post",
					url:"/work_infos",
					data:d,
					contentType:"application/json",
					dataType:"json",
					success:function(res){
						if(res.status == 200){
							mui.toast("保存成功！");
							mui('#czPopover').popover('toggle');//show hide toggle
						}
					},
					error:function(){
						mui.toast("保存失败！");
						mui('#czPopover').popover('toggle');//show hide toggle
					}
				}); 
				
				
				
				//
			});
			/*var dtPicker = new mui.DtPicker(); //初始化一次
			$("#time").click(function(){
				//$("#czPopover").css("z-index","10");
			     dtPicker.show(function (rs) { 
			     	$("#time").val(rs.text) 
			    })
			});*/
		},
		getRadioRes:function(className){
			var rdsObj = document.getElementsByClassName(className);
			var checkVal = null;
			for(i = 0; i < rdsObj.length; i++){
				if(rdsObj[i].checked){
					checkVal = rdsObj[i].value;
				}
			}
			return checkVal;
		}
	};
	
	return {
		init:function(){
			console.log("初始化列表");
			mui.ready(function() {
				nsgl.getScrollData();
				nsgl.bindClick();
			});
			mui('.mui-scroll-wrapper').scroll();//触发滚动 
			mui(".mui-slider").slider();//滑动效果
			
			
			//此处最好动态声明多个变量
			itemShow=true;
			item2Show = false,item3Show = false,
			item4Show = false,item5Show = false,item6Show = false;
			document.querySelector('.mui-slider').addEventListener('slide', 
			function(event) {
				var index =event.detail.slideNumber;
					var  pullRefreshEl = document.querySelectorAll('.mui-slider-group .mui-scroll')[index];
				//console.log(index);
				//主动触发上拉加载
				if(index=== 0&&!itemShow){
			  		itemShow=true;
				}else if (index=== 1&&!item2Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item2Show = true;//改变标志位，下次直接显示
				} else if (index === 2&&!item3Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item3Show = true;
				}else if (index === 3&&!item4Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item4Show = true;
				}else if (index === 4&&!item5Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item5Show = true;
				}else if (index === 5&&!item6Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item6Show = true;
				}
			});
			
			
		}
	}
});