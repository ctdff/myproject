define(["jquery","cache","common","mui","pullToRefresh","template"],function($,Cache,common,mui,pullToRefresh,template){
	var chooseInfo;
	var workList = {
		getScrollData:function(cId){
	        $.ajax({
	        	type:"get",
	        	url:"/farming/work_types",
	        	data:{cId:cId},
	        	success:function(res){
	        		console.log(res);
	        		var array = res.data;
	        		var tabHtml=``;
					var groupHtml=``;
					array.unshift({id:'all',wName:'全部'});
					$.each(array, function(index,item) {
						var active = index==0?"mui-active":"";
						tabHtml+=`<a class="mui-control-item `+active+`" href="#item_`+item.id+`">
								`+item.wName+`
							</a>`;
						groupHtml+=`<div id="item_`+item.id+`" class="mui-slider-item mui-control-content `+active+`">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<ul id="ul_`+item.id+`" curpage=1>
									</ul>
								</div>
							</div>
						</div>`;
					});
					$("#scrollTab").html(tabHtml);
					$("#sliderGroup").html(groupHtml);
					mui('.mui-scroll-wrapper').scroll();//触发滚动
					mui(".mui-slider").slider();//这句话必要
					workList.initPage();
	        	}
	        });
		},
		initPage:function(){
			$.each(document.querySelectorAll('.mui-slider-group .mui-scroll'), function (index, pullRefreshEl) {
	            mui(pullRefreshEl).pullToRefresh({
	            	down: {
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							setTimeout(function() {
								console.log("刷新");
								$(ul).attr("curpage",1);
								self.refresh(true);
								self.endPullDownToRefresh();
								workList.createFragment(ul,index,self,1,true);        
							}, 1000);
						}
					},
					up: {
						auto:index==0?true:false, //自动执行一次上拉加载，可选；
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							var pageNum = Number($(ul).attr("curpage"));
							setTimeout(function() {
								console.log("加载");
								workList.createFragment(ul,index,self,pageNum);        
							}, 1000);
						}
					}
	            });
	        });
		},
		createFragment:function(ul,index,self,pageNum,reverse) {
	        var ajaxUrl=null;
	        var farmingBatchNo =chooseInfo.batchNo; //档案编号
	       
			var param={cId:chooseInfo.cId,pageNumber:pageNum,pageSize:10,
			farmingBatchNo:farmingBatchNo};
			var wtId =  ul.id.split("_")[1];//行业类型
	        if(wtId!="all"){
	        	param.wtId=wtId;
	        }
	        console.log(wtId);
	        $.ajax({
	        	type:"get",
	        	url:"/farming_query",
	        	data:param,
	        	success:function(res){
	        		console.log(res);
	        		if(res.status==200){
		        		var datas =res.data;
		        		console.log(datas);
		        		if(datas.length == 0){
		                  $(ul).find('li').remove();
		                  self.endPullUpToRefresh(true);//一定要设置为true
		                }else{
		                	var html = template("workListTepm", {list:datas});
							if(reverse){
								$(ul).empty();
								self.endPullDownToRefresh();
							}
							$(ul).append(html);//对应的ul
							//总页数大于当前页面
							var hasNext = res.totalPage>pageNum;
							if(hasNext){
								pageNum++;
								$(ul).attr("curpage",pageNum);
							}
		                	self.endPullUpToRefresh(!hasNext);
		                }
		        	}
	        	}
	        });
		}
	};
	
	return {
		init:function(){
			console.log("初始化列表");
			$("footer").hide();
			var offsetHeight= document.body.offsetHeight;
			var height=offsetHeight-52;
			$("#content").height(height);
			$("#slider").css("bottom","0");
			chooseInfo = Cache.getJSON("chooseInfo");
			$("#batchNo").html(chooseInfo.batchNo);
			workList.getScrollData(chooseInfo.cId);//大类id
			//此处最好动态声明多个变量
			itemShow=true;
			item2Show = false,item3Show = false,
			item4Show = false,item5Show = false,item6Show = false;
			document.querySelector('.mui-slider').addEventListener('slide', 
			function(event) {
				var index =event.detail.slideNumber;
					var  pullRefreshEl = document.querySelectorAll('.mui-slider-group .mui-scroll')[index];
				//console.log(index);
				//主动触发上拉加载
				if(index=== 0&&!itemShow){
			  		itemShow=true;
				}else if (index=== 1&&!item2Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item2Show = true;//改变标志位，下次直接显示
				} else if (index === 2&&!item3Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item3Show = true;
				}else if (index === 3&&!item4Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item4Show = true;
				}else if (index === 4&&!item5Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item5Show = true;
				}else if (index === 5&&!item6Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item6Show = true;
				}
			});
		}
	}
});