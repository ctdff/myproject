define(["jquery","cache","common","mui"],function($,Cache,common,mui){
	var mine = {
		initUserInfo:function(){
			var userInfo = Cache.getJSON("pms-userInfo");
			console.log(userInfo);
		},
		bindClick:function(type){
			if(type=="/resetpassword"){
				$("#savePwd").click(function(){
					var oldPwd = $("#oldPwd").val();
					var newPwd = $("#newPwd").val();
					var confirmPwd = $("#confirmPwd").val();
					if(oldPwd==""||oldPwd==null){
						mui.toast("请输入原密码");
						return false;
					}
					if(newPwd==""||newPwd==null){
						mui.toast("请输入新密码");
						return false;
					}
					if(confirmPwd==""||confirmPwd==null){
						mui.toast("请输入确认密码");
						return false;
					}
					//ajax请求
				})
			}else if(type=="/mine"){
				$("footer ul li").unbind("click");
				$("footer ul li").click(function(){
					var url = $(this).data("u");
					$(this).addClass("active").siblings().removeClass("active");
					router.go(url);
				})
				$("#layout").click(function(){
					router.go("#/login");
				})
			}
			
		}
	};
	
	return {
		init:function(){
			console.log("mine js...");
			//工人中心公用js
			var hash = location.href.substring(location.href.indexOf("#")+1);
			console.log(hash);
			mine.bindClick(hash);
			if(hash=="/mine"){
				$("footer").show();//底部菜单隐藏
			}else{
				$("footer").hide();//底部菜单隐藏
			}
			if(hash=="/details"){
				mine.initUserInfo();
			}
		}
	}
});