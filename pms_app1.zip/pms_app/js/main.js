require.config({
	baseUrl: "js/",
	paths:{
		"jquery":"jquery/jquery-1.11.1",
		"mui":"mui/mui.min",
		"picker":"mui/mui.picker.min",
		"router":"router/router",
		"template":"template-web",
		"cache":"cache/cache",
		"pullToRefresh":"mui/mui.pullToRefresh",
		"material":"mui/mui.pullToRefresh.material"
	},
	shim:{
		picker:{
			deps:["mui"]
		},
		pullToRefresh:{
			deps:["mui"]
		}
	}
});

require(["index","common","router","index","login","home","workList","nsgl","mine"], function(index,common,router,index,login,home,workList,nsgl,mine){
	var router_mappings = [
		{
			path:"/", resource:"views/login.html", componet:login
		},
		{
			path:"/login", resource:"views/login.html", componet:login
		},
		{
			path:"/home", resource:"views/home.html", componet:home
		},
		{
			path:"/workList", resource:"views/workList.html", componet:workList	
		}
		,
		{
			path:"/nsgl", resource:"views/nsgl.html", componet:nsgl	
		},
		{
			path:"/mine", resource:"views/mine.html", componet:mine	
		},
		{
			path:"/details", resource:"views/details.html", componet:mine	
		},
		{
			path:"/resetpassword", resource:"views/resetpassword.html", componet:mine	
		},
		{
			path:"/about", resource:"views/about.html", componet:mine	
		}
	];

	router.render("workcontent");
	router.mapper(router_mappings);
	router.init();
	//是否登录？
	if(!common.isLogin()){
		router.go("/login");
		return false;
	}
	
	
});