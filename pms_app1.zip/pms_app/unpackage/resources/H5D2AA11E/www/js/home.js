define(["jquery","cache","common","mui","pullToRefresh","template"],function($,Cache,common,mui,pullToRefresh,template){
	var userInfo ;
	var home = {
		getScrollData:function(){
	        $.ajax({
	        	type:"get",
	        	url:"/select/industry_categories",
	        	data:{cId:'1,2'},
	        	success:function(res){
	        		console.log(res);
	        		home.initscrollTab(res.data);
	        	}
	        });
		},
		//初始行业类型
		initscrollTab:function(array){
			var tabHtml=``;
			var groupHtml=``;
			$.each(array, function(index,item) {
				var active = index==0?"mui-active":"";
				tabHtml+=`<a class="mui-control-item `+active+`" href="#item_`+item.id+`">
						`+item.cName+`
					</a>`;
				groupHtml+=`<div id="item_`+item.id+`" class="mui-slider-item mui-control-content">
					<div class="mui-scroll-wrapper">
						<div class="mui-scroll">
							<ul id="ul_`+item.id+`">
							</ul>
						</div>
					</div>
				</div>`;
			});
			$("#pro_type").html(tabHtml);
			$("#homeSlider").html(groupHtml);
			mui('.mui-scroll-wrapper').scroll();//触发滚动
			mui(".mui-slider").slider();//这句话必要
			home.initPage();
		},
		//获取种植档案数据
		getFarmingPlans:function(type){
			var param={cId:type,pageNumber:'1',pageSize:10,epId:'',
			farmingStatus:0,baseId:'1c62deb13fa743648df747c3666f4496'};
	        $.ajax({
	        	type:"get",
	        	url:"/farmingPlans",
	        	data:param,
	        	success:function(res){
	        		console.log(res);
	        		//home.initscrollTab(res.data);
	        	}
	        });
		},
		bindClick:function(){
			//点击事件
			mui('#homeSlider').on('tap', '.item', function() {
				var id = this.id;
				var typeCode =$("#pro_type").find(".mui-active").attr("href");
				console.log(id,typeCode);
				console.log("档案编号",id,typeCode);
				//保存 跳转 类型
				Cache.set("chooseInfo",{batchNo:id,cId:typeCode.split("_")[1]});
				router.go("#/workList")
			});
		},
		initPage:function(){
			$("footer ul li").unbind("click");
			$("footer ul li").click(function(){
				var url = $(this).data("u");
				$(this).addClass("active").siblings().removeClass("active");
				router.go(url);
			});
			//循环初始化所有下拉刷新，上拉加载。
	        $.each(document.querySelectorAll('.mui-slider-group .mui-scroll'), function (index, pullRefreshEl) {
	        	//console.log(pullRefreshEl);
	            mui(pullRefreshEl).pullToRefresh({
	            	down: {
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							setTimeout(function() {
								console.log("刷新");
								$(ul).attr("curpage",1);
								//self.endPullDownToRefresh();//如歌触发为down的话就一定要这行
								//mui(pullRefreshEl).pullToRefresh().refresh(true);
								home.createFragment(ul,index,self,1,true);        
							}, 1000);
						}
					},
					up: {
						auto:index==0?true:false, //自动执行一次上拉加载，可选；
						callback: function() {
							var self = this;
							var ul = self.element.querySelector('ul');
							var pageNum = Number($(ul).attr("curpage"));
							setTimeout(function() {
								console.log("加载");
								home.createFragment(ul,index,self,pageNum);        
							}, 1000);
						}
					}
	            });
	        });
			
			
		},
		createFragment:function(ul,index,self,pageNum,reverse) {
	        var ajaxUrl=null;
	        var type = ul.id.split("_")[1];//行业类型
	        var tempName = "template_"+index;
			var param={cId:type,pageNumber:pageNum,pageSize:10,epId:'',
			farmingStatus:0,baseId:'1c62deb13fa743648df747c3666f4496'};
	        $.ajax({
	        	type:"get",
	        	url:"/farmingPlans",
	        	data:param,
	        	success:function(res){
	        		console.log(res);
	        		if(res.status==200){
		        		var datas =res.data;
		        		if(datas.length == 0){
		                  $(ul).find('li').remove();
		                  self.endPullUpToRefresh(true);//一定要设置为true
		                }else{
							/*var fillDatas=[];
							var newObj = item;
		                	fillDatas.push(newObj);*/
		                	$.each(datas,function(index,item){
		                		var farmingPlanAreas = item.farmingPlanAreas;
		                		var totalArea=0;
		                		var areaNames=[];
		                		$.each(farmingPlanAreas,function(i,it){
		                			areaNames.push(it.areaName);
		                			totalArea+=it.farmingArea;
		                		});
		                		item.areaNames=areaNames.join(",");
		                		item.totalArea=totalArea;
		                	});
		                	var html = template(tempName, {list:datas});
							if(reverse){
								$(ul).empty();
								self.endPullDownToRefresh();
							}
							$(ul).append(html);//对应的ul
							//总页数大于当前页面
							var hasNext = res.totalPage>pageNum;
							if(hasNext){
								pageNum++;
								$(ul).attr("curpage",pageNum);
							}
		                	self.endPullUpToRefresh(!hasNext);
		                }
		        	}
	        	}
	        });
		},
		initUseInfo:function(epId){
			$.ajax({
				type:"get",
				url:"/baseMgr",
				data:{epId:epId},
				success:function(res){
					console.log(res);
					Cache.set("pms-userInfo",res.data[0]);
				}
			});
		}
	};
	return {
		init:function(){
			console.log("初始化首页");
			userInfo = Cache.getJSON("pms-app-user"); 
			
			home.initUseInfo(userInfo.loginUserId);
			$('footer').show();
			mui(".mui-slider").slider();//滑动效果
			mui.ready(function() {
				home.getScrollData();
				home.bindClick();
				//home.getFarmingPlans(1);
			});
		   	itemShow=true;
			item2Show = false,item3Show = false;
			document.querySelector('.mui-slider').addEventListener('slide', 
			function(event) {
				var index =event.detail.slideNumber;
					var  pullRefreshEl = document.querySelectorAll('.mui-slider-group .mui-scroll')[index];
				//console.log(index);
				//主动触发上拉加载
				if(index=== 0&&!itemShow){
			  		itemShow=true;
				}else if (index=== 1&&!item2Show) {
					mui(pullRefreshEl).pullToRefresh().pullUpLoading();
				    item2Show = true;//改变标志位，下次直接显示
				} else if (index === 2&&!item3Show) {
					//mui(pullRefreshEl).pullToRefresh().pullDownLoading();
				    item3Show = true;
				}
			});
		}
	}
});